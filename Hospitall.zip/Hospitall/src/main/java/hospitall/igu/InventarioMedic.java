
package hospitall.igu;

import hospitall.logica.Controladora;
import hospitall.logica.Inventario;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class InventarioMedic extends javax.swing.JFrame {
 Controladora control = new Controladora();

  
    public InventarioMedic() {
    // control = new Controladora();

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txtCodigoP = new javax.swing.JTextField();
        lblCodigoP = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        txtNotas = new javax.swing.JTextField();
        txtPrecioP = new javax.swing.JTextField();
        lblNombreP = new javax.swing.JLabel();
        lblNotas = new javax.swing.JLabel();
        btnPrimerRegistro = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnUltimoRegistro = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        txtNombreP = new javax.swing.JTextField();
        lblPrecioP = new javax.swing.JLabel();
        btnLimpiar = new javax.swing.JButton();
        btnAñadirRegistro2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TblDatos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 121, 198));

        jButton1.setBackground(new java.awt.Color(0, 121, 198));
        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("<  REGISTRO DE PRODUCTOS");
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 121, 198));

        txtCodigoP.setBackground(new java.awt.Color(0, 86, 119));
        txtCodigoP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtCodigoP.setForeground(new java.awt.Color(255, 255, 255));
        txtCodigoP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblCodigoP.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        lblCodigoP.setForeground(new java.awt.Color(255, 255, 255));
        lblCodigoP.setText("Código de Producto:");

        lblDescripcion.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        lblDescripcion.setForeground(new java.awt.Color(255, 255, 255));
        lblDescripcion.setText("Descripción:");

        txtDescripcion.setBackground(new java.awt.Color(0, 86, 119));
        txtDescripcion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtDescripcion.setForeground(new java.awt.Color(255, 255, 255));
        txtDescripcion.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtNotas.setBackground(new java.awt.Color(0, 86, 119));
        txtNotas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtNotas.setForeground(new java.awt.Color(255, 255, 255));
        txtNotas.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtPrecioP.setBackground(new java.awt.Color(0, 86, 119));
        txtPrecioP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtPrecioP.setForeground(new java.awt.Color(255, 255, 255));
        txtPrecioP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtPrecioP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioPActionPerformed(evt);
            }
        });

        lblNombreP.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        lblNombreP.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreP.setText("Nombre del Producto:");

        lblNotas.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        lblNotas.setForeground(new java.awt.Color(255, 255, 255));
        lblNotas.setText("Notas:");

        btnPrimerRegistro.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnPrimerRegistro.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\editar.png")); // NOI18N
        btnPrimerRegistro.setText("    Primer registro");

        btnGuardar.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\disquete.png")); // NOI18N
        btnGuardar.setText("       Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\buscar.png")); // NOI18N
        btnBuscar.setText("    Buscar");

        btnUltimoRegistro.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnUltimoRegistro.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\verificar.png")); // NOI18N
        btnUltimoRegistro.setText("    Ultimo registro");

        btnEliminar.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\eliminar.png")); // NOI18N
        btnEliminar.setText("    Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnActualizar.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnActualizar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\boton-actualizar.png")); // NOI18N
        btnActualizar.setText("     Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        txtNombreP.setBackground(new java.awt.Color(0, 86, 119));
        txtNombreP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtNombreP.setForeground(new java.awt.Color(255, 255, 255));
        txtNombreP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblPrecioP.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        lblPrecioP.setForeground(new java.awt.Color(255, 255, 255));
        lblPrecioP.setText("Precio del producto");

        btnLimpiar.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnLimpiar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\limpiar.png")); // NOI18N
        btnLimpiar.setText("    Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnAñadirRegistro2.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        btnAñadirRegistro2.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\anadir.png")); // NOI18N
        btnAñadirRegistro2.setText("    Añadir registro");
        btnAñadirRegistro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAñadirRegistro2ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\medicamento.png")); // NOI18N

        TblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(TblDatos);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnPrimerRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(96, 96, 96)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAñadirRegistro2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnUltimoRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(80, 80, 80)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 859, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCodigoP, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblCodigoP, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(54, 54, 54)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblNotas, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNotas, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPrecioP, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblPrecioP, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(31, 31, 31))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(lblCodigoP)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCodigoP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblDescripcion)
                                    .addComponent(lblNotas)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblPrecioP)
                                    .addComponent(lblNombreP))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtPrecioP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDescripcion)
                            .addComponent(txtNotas)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPrimerRegistro)
                    .addComponent(btnAñadirRegistro2)
                    .addComponent(btnUltimoRegistro)
                    .addComponent(btnBuscar))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnEliminar)
                    .addComponent(btnActualizar)
                    .addComponent(btnLimpiar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 874, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addGap(17, 17, 17)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtPrecioPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioPActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
    txtCodigoP.setText("");
    txtNombreP.setText("");
    txtPrecioP.setText("");
    txtDescripcion.setText("");
    txtNotas.setText("");
    
    
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        
        String codigop = txtCodigoP.getText();
        String nombre = txtNombreP.getText();
        String preciop = txtPrecioP.getText();
        String descripcion = txtDescripcion.getText();
        String notas = txtNotas.getText();
        
        control.guardar(codigop, nombre, preciop, descripcion, notas);
        
        JOptionPane optionPane = new JOptionPane("Se guardo correctamente");
        optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog("Guardao Exitoso");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
            }//GEN-LAST:event_btnGuardarActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

        cargarTabla();
    }//GEN-LAST:event_formWindowOpened

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
      cargarTabla();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed


     //Controlo que la tabla no este vacía
     if (TblDatos.getRowCount()>0){
         //Controlo que se haya seleccionado un registro 
         if(TblDatos.getSelectedRow()!= -1){
             int id = Integer.parseInt(String.valueOf(TblDatos.getValueAt(TblDatos.getSelectedRow(), 0)));
             
             //LLamo al método borrar
             control.borrarProducto(id);
             
        mostrarMensaje("Procuto eliminado correctamente", "Info", "Borrado de Producto");
         }
         
         else {
             mostrarMensaje( "No selecciono ningún Producto", "Error", "Error al eliminar");
         }
     }
     else{
         mostrarMensaje( "No existen columnas para eliminar", "Error", "Error al eliminar");
     }

    }                                           
                                            
    public void mostrarMensaje(String mensaje, String tipo, String titulo){
        JOptionPane optionPane = new JOptionPane(mensaje);
        if(tipo.equals("Info")){
           optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE); 
        }
        else if(tipo.equals("Error")){
          optionPane.setMessageType(JOptionPane.ERROR_MESSAGE);  
        }
        JDialog dialog = optionPane.createDialog("Guardado Exitoso");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnAñadirRegistro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAñadirRegistro2ActionPerformed
        String codigop = txtCodigoP.getText();
        String nombre = txtNombreP.getText();
        String preciop = txtPrecioP.getText();
        String descripcion = txtDescripcion.getText();
        String notas = txtNotas.getText();
        
        control.guardar(codigop, nombre, preciop, descripcion, notas);
        
        JOptionPane optionPane = new JOptionPane("Se añadio registro nuevo correctamente");
        optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog("Guardado Exitoso");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
                        


    }//GEN-LAST:event_btnAñadirRegistro2ActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TblDatos;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAñadirRegistro2;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnPrimerRegistro;
    private javax.swing.JButton btnUltimoRegistro;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCodigoP;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblNombreP;
    private javax.swing.JLabel lblNotas;
    private javax.swing.JLabel lblPrecioP;
    private javax.swing.JTextField txtCodigoP;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombreP;
    private javax.swing.JTextField txtNotas;
    private javax.swing.JTextField txtPrecioP;
    // End of variables declaration//GEN-END:variables

    private void cargarTabla() {
        
        
         //definir el modelo que queremos que tenga la tabla 
         DefaultTableModel modeloTabla = new DefaultTableModel(){
             
             //que las filas y columnas no sean editables
             @Override
             public boolean isCellEditable(int row, int column){
                 return false;
             }
         };
         
         //establecemos los nombres de las columnas
         String titulos[] = {"CódigoP", "NombreP", "Precio", "Descripción","Notas"};
         modeloTabla.setColumnIdentifiers(titulos);
         
         
         
         //cargar los datos desde la base de datos
         List <Inventario> listaProductos = control.traerProductos();
         
         
          //recorrer la lista y mostrat cada uno de los elementos en la tabla
         if(listaProductos!= null){
             for (Inventario invent : listaProductos){
            Object[] objeto = {
            invent.getCodigo_producto(),
            invent.getNombre_producto(),
            invent.getPrecio_producto(),
            invent.getDescripcion(),
            invent.getNotas()
        };
        modeloTabla.addRow(objeto);
             }
         }
         
         TblDatos.setModel(modeloTabla);
    }
    
}
