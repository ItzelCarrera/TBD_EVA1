
package hospitall.igu;

import hospitall.logica.Citas;
import hospitall.logica.Controladora;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class AdminCitas extends javax.swing.JFrame {
 Controladora control = null;

    public AdminCitas() {
      control = new Controladora();

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cmbCitas = new javax.swing.JComboBox<>();
        btnListo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TblDatos = new javax.swing.JTable();
        btnAtras = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 121, 198));

        jPanel2.setBackground(new java.awt.Color(0, 121, 198));

        cmbCitas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Citas Pagadas", "Citas Sin Pagar", "Citas Canceladas", "Citas Facturadas", "Síntomas/Especialista" }));
        cmbCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCitasActionPerformed(evt);
            }
        });

        btnListo.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\cheque.png")); // NOI18N

        btnGuardar.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\disquete.png")); // NOI18N
        btnGuardar.setText("    Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\eliminar.png")); // NOI18N
        btnEliminar.setText("   Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnActualizar.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N
        btnActualizar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\boton-actualizar.png")); // NOI18N
        btnActualizar.setText("     Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\alba\\Desktop\\Imagen\\buscar.png")); // NOI18N
        btnBuscar.setText("     Buscar");

        TblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(TblDatos);

        btnAtras.setBackground(new java.awt.Color(0, 121, 198));
        btnAtras.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 24)); // NOI18N
        btnAtras.setForeground(new java.awt.Color(255, 255, 255));
        btnAtras.setText("<  CITAS");
        btnAtras.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAtras.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbCitas, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnListo, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                                .addComponent(btnActualizar)
                                .addGap(66, 66, 66)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane2)
                    .addComponent(btnAtras, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAtras)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbCitas, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnListo))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnBuscar)
                        .addComponent(btnActualizar))
                    .addComponent(btnEliminar)
                    .addComponent(btnGuardar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCitasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbCitasActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
     
     //Controlo que la tabla no este vacía
     if (TblDatos.getRowCount()>0){
         //Controlo que se haya seleccionado un registro 
         if(TblDatos.getSelectedRow()!= -1){
             
             //obtengo el id del registro a editar
             int id = Integer.parseInt(String.valueOf(TblDatos.getValueAt(TblDatos.getSelectedRow(), 0)));
               ModificarCita pantallaModif = new ModificarCita(id);
               pantallaModif.setVisible(true);
               pantallaModif.setLocationRelativeTo(null);
               this.dispose();
         }
     
     
         else {
             mostrarMensaje( "No selecciono ningúna cita", "Error", "Error al eliminar");
         }
     }
     else{
         mostrarMensaje( "No existen columnas para eliminar", "Error", "Error al eliminar");
     }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasActionPerformed
   // Crear una instancia de la ventana anterior y hacerla visible
    Principal ventanaAnterior = new Principal();
    ventanaAnterior.setVisible(true);
    
    // Cerrar la ventana actual
    this.dispose();    }//GEN-LAST:event_btnAtrasActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

        cargarTabla();

    }//GEN-LAST:event_formWindowOpened

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

     //Controlo que la tabla no este vacía
     if (TblDatos.getRowCount()>0){
         //Controlo que se haya seleccionado un registro 
         if(TblDatos.getSelectedRow()!= -1){
             int id = Integer.parseInt(String.valueOf(TblDatos.getValueAt(TblDatos.getSelectedRow(), 0)));
             
             //LLamo al método borrar
             control.borrarCita(id);
             
        mostrarMensaje("Cita eliminada correctamente", "Info", "Borrado de Cita");
         }
         
         else {
             mostrarMensaje( "No selecciono ningúna cita", "Error", "Error al eliminar");
         }
     }
     else{
         mostrarMensaje( "No existen columnas para eliminar", "Error", "Error al eliminar");
     }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
     
        cargarTabla();

    }//GEN-LAST:event_btnActualizarActionPerformed
    public void mostrarMensaje(String mensaje, String tipo, String titulo){
        JOptionPane optionPane = new JOptionPane(mensaje);
        if(tipo.equals("Info")){
           optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE); 
        }
        else if(tipo.equals("Error")){
          optionPane.setMessageType(JOptionPane.ERROR_MESSAGE);  
        }
        JDialog dialog = optionPane.createDialog("Guardado Exitoso");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TblDatos;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnListo;
    private javax.swing.JComboBox<String> cmbCitas;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private void cargarTabla() {
        
         //definir el modelo que queremos que tenga la tabla 
         DefaultTableModel modeloTabla = new DefaultTableModel(){
             
             //que las filas y columnas no sean editables
             @Override
             public boolean isCellEditable(int row, int column){
                 return false;
             }
         };
         
         //establecemos los nombres de las columnas
         String titulos[] = {"ID", "Nombre", "Tel", "E-mail","Síntomas", "Fecha", "Especialista", "Genero", "Hora"};
         modeloTabla.setColumnIdentifiers(titulos);
         
         
         //cargar los datos desde la base de datos
         List <Citas> listaCitas = control.traerCita();
         
         //recorrer la lista y mostrat cada uno de los elementos en la tabla
         if(listaCitas!= null){
             for (Citas cita : listaCitas){
             
            Object[] objeto = {
            cita.getId(),
            cita.getNombrePaciente(),
            cita.getTelPaciente(),
            cita.getEmail_paciente(),
            cita.getSintomas_paciente(),
            cita.getGenero(),
            cita.getHora(),
            cita.getEspeciaista_asignado(),
            cita.getFecha(),
            cita.getUnPaciente()
        };
        modeloTabla.addRow(objeto);
             }
         }
         
         TblDatos.setModel(modeloTabla);
    }
}
