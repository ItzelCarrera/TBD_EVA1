
package hospitall;

import hospitall.igu.Principal;


public class Hospitall {

    public static void main(String[] args) {
        Principal princ = new Principal ();
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);    }
}
