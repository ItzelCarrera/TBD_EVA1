
package hospitall.persistencia;

import hospitall.logica.Citas;
import hospitall.logica.Especialista;
import hospitall.logica.Inventario;
import hospitall.logica.Pacientes;
import java.util.List;

public class ControladoraPersistencia {
    
    CitaJpaController citaJpa = new CitaJpaController();
    EspecialistaJpaController especialistaJpa= new EspecialistaJpaController();
    InventarioJpaController inventarioJpa = new InventarioJpaController();
    PacientesJpaController pacientesJpa = new PacientesJpaController();

    public void guardar(Citas cita, Pacientes pas) {
        citaJpa.create(cita);
        
        pacientesJpa.create(pas);
    }

    public void guardar(Especialista esp) {
        especialistaJpa.create(esp);
    }

    public void guardar(Inventario invent) {
       inventarioJpa.create(invent);
    }

    
    public List<Citas> traerCita() {
        return citaJpa.findACitasEntities();
        //return pacientesJpa.findAllPacientes();
    }

    public List<Especialista> traerEspecialistas() {
        return especialistaJpa.findAllEspecialistas();
    }

    public List<Inventario> traerProductos() {
        return inventarioJpa.findAllInventarios();
    }

    public void borarCita(int id) {
        citaJpa.destroy(id);
    }

    public void borrarProducto(int id) {
        inventarioJpa.destroy(id);
    }

    public void borrarPaciente(int id) {
        pacientesJpa.destroy(id);
    }

    public Citas traerCita(int id) {
        return (Citas) citaJpa.findACitasEntities();
    }
    
    
}
