package hospitall.persistencia;

import hospitall.logica.Especialista;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 * Controlador JPA para la entidad Especialista.
 */
public class EspecialistaJpaController implements Serializable{

    public EspecialistaJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    private EntityManagerFactory emf = null;

    public EspecialistaJpaController() {
        emf = Persistence.createEntityManagerFactory("HospitalPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Especialista especialista) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(especialista);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Especialista especialista) throws EntityNotFoundException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            especialista = em.merge(especialista);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new Exception("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws EntityNotFoundException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Especialista especialista;
            try {
                especialista = em.getReference(Especialista.class, id);
                especialista.getId(); // Este paso es necesario para lanzar una excepción si el especialista no existe.
            } catch (EntityNotFoundException enfe) {
                throw enfe;
            }
            em.remove(especialista);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Especialista> findAllEspecialistas() {
        // Inicializar el EntityManagerFactory
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HospitalPU");
        // Crear el EntityManager
        EntityManager em = emf.createEntityManager();

        try {
            // Crear la consulta JPQL para seleccionar todos los especialistas
            TypedQuery<Especialista> query = em.createQuery("SELECT e FROM Especialista e", Especialista.class);
            // Ejecutar la consulta y devolver el resultado
            return query.getResultList();
        } finally {
            // Cerrar el EntityManager y el EntityManagerFactory
            em.close();
            emf.close();
        }
    }

    public int getEspecialistaCount() {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select count(o) from Especialista as o");
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
}
