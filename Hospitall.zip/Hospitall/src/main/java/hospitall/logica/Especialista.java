
package hospitall.logica;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Especialista {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    
   @Basic
    private String nombre;
    private String sexo;
    private String telefono;
    private String especialidad;
    private int edad;

    public Especialista() {
    }

    public Especialista(int id, String nombre, String sexo, String telefono, String especialidad) {
        this.id = id;
        this.nombre = nombre;
        this.sexo = sexo;
        this.telefono = telefono;
        this.especialidad = especialidad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

     public int getEdad() {
        return id;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

   


    
    
}
