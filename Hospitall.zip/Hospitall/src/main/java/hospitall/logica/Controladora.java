
package hospitall.logica;

import hospitall.igu.Cita;
import hospitall.persistencia.ControladoraPersistencia;
import java.util.List;


public class Controladora {
    
    ControladoraPersistencia controlPersis = new ControladoraPersistencia();

    public void guardar(String email, String genero, String hora, 
            String nombre, String sintomas, String tel, String numCita, String espAsign) {
      
        Citas cita = new Citas();
        cita.setHora(hora);
        cita.setEspeciaista_asignado(espAsign);
        
        Pacientes pas = new Pacientes();
        pas.setEmail_paciente(email);
        pas.setGenero(genero);
        pas.setNombrePaciente(nombre);
        pas.setSintomas_paciente(sintomas);
        pas.setTelPaciente(tel);
        
        controlPersis.guardar(cita, pas);
    }

    public void guardar(String especialista, String nombre, String tel, 
            String sexo, int edad, String especialidad) {
        
        Especialista esp = new Especialista();
        esp.setEspecialidad(especialista);
        esp.setNombre(nombre);
        esp.setTelefono(tel);
        esp.setSexo(sexo);
        esp.setEdad(edad);
        esp.setEspecialidad(especialidad);
        
      controlPersis.guardar(esp);

    }

   

    public void guardar(String codigop, String nombre, 
            String preciop, String descripcion, String notas) {
        
        Inventario invent = new Inventario();
        invent.setNombre_producto(nombre);
        invent.setPrecio_producto(preciop);
        invent.setDescripcion(descripcion);
        invent.setNotas(notas);
        
        
      controlPersis.guardar(invent);

    }

    public List<Citas> traerCita() {
        return controlPersis.traerCita();
    }

    public List<Especialista> traerEspecialistas() {
        return controlPersis.traerEspecialistas();
    }

    public List<Inventario> traerProductos() {
        return controlPersis.traerProductos();
        
    }

    public void borrarCita(int id) {
        controlPersis.borarCita(id);
    }

    public void borrarProducto(int id) {
        controlPersis.borrarProducto(id);
    }

    public void borrarPaciente(int id) {
        controlPersis.borrarPaciente(id);
    }

  

    public Citas Cita(int id) {
        return controlPersis.traerCita(id);
        
    }

  
    
}
