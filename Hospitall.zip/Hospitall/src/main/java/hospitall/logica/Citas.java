
package hospitall.logica;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Citas  {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    
    @Basic
    private String nombrePaciente;
    private String telPaciente;
    private String email_paciente;
    private String sintomas_paciente;
    private String genero;
    private String hora;
    private String especiaista_asignado;
    
    
    @Temporal(TemporalType.DATE)
    private Date fecha;

    @OneToOne
    private Pacientes unPaciente;

    public Citas() {
    }

    public Citas(int id, String nombrePaciente, String telPaciente, String email_paciente, String sintomas_paciente, String genero, String hora, String especiaista_asignado, Date fecha, Pacientes unPaciente) {
        this.id = id;
        this.nombrePaciente = nombrePaciente;
        this.telPaciente = telPaciente;
        this.email_paciente = email_paciente;
        this.sintomas_paciente = sintomas_paciente;
        this.genero = genero;
        this.hora = hora;
        this.especiaista_asignado = especiaista_asignado;
        this.fecha = fecha;
        this.unPaciente = unPaciente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) {
        this.nombrePaciente = nombrePaciente;
    }

    public String getTelPaciente() {
        return telPaciente;
    }

    public void setTelPaciente(String telPaciente) {
        this.telPaciente = telPaciente;
    }

    public String getEmail_paciente() {
        return email_paciente;
    }

    public void setEmail_paciente(String email_paciente) {
        this.email_paciente = email_paciente;
    }

    public String getSintomas_paciente() {
        return sintomas_paciente;
    }

    public void setSintomas_paciente(String sintomas_paciente) {
        this.sintomas_paciente = sintomas_paciente;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEspeciaista_asignado() {
        return especiaista_asignado;
    }

    public void setEspeciaista_asignado(String especiaista_asignado) {
        this.especiaista_asignado = especiaista_asignado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Pacientes getUnPaciente() {
        return unPaciente;
    }

    public void setUnPaciente(Pacientes unPaciente) {
        this.unPaciente = unPaciente;
    }

   

   

    
    
    

    
}
